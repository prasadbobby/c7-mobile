import { auth } from "@clerk/nextjs/server";
import prisma from "@/prisma/prisma";
import { NextRequest, NextResponse } from "next/server";
import { mkdir, writeFile, rm } from "fs/promises";
import { join } from "path";

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  const { userId }  = await auth();

  if (!userId) {
    throw new Error("You must be signed in to view this page.");
  }

  const { searchParams } = new URL(request.url);
  const limit = parseInt(searchParams.get("limit") || "50");
  const page = parseInt(searchParams.get("page") || "1");
  const search = searchParams.get("search") || "";
  const category = searchParams.get("category") || "";
  const isFavorites = searchParams.get("favorites") === "true";

  // Check if user is admin for full exercise access
  const userInfo = await prisma.userInfo.findUnique({
    where: { userId },
    select: { role: true },
  });

  const isAdmin = userInfo && (userInfo.role === "ADMIN" || userInfo.role === "SUPER_ADMIN");

  let whereClause: any = {};

  // If requesting favorites or not an admin, show only favorited exercises
  if (isFavorites || !isAdmin) {
    whereClause.favouritedBy = {
      some: {
        userId: userId,
      },
    };
  }

  // Add search filter
  if (search) {
    whereClause.OR = [
      { name: { contains: search, mode: "insensitive" } },
      { category: { contains: search, mode: "insensitive" } },
      { primary_muscles: { has: search } },
      { secondary_muscles: { has: search } },
    ];
  }

  // Add category filter
  if (category) {
    whereClause.category = category;
  }

  const [exercises, totalCount] = await Promise.all([
    prisma.exercise.findMany({
      where: whereClause,
      select: {
        id: true,
        name: true,
        category: true,
        level: true,
        primary_muscles: true,
        secondary_muscles: true,
        image: true,
        equipment: true,
      },
      orderBy: [
        { name: "asc" }
      ],
      skip: (page - 1) * limit,
      take: limit,
    }),
    prisma.exercise.count({ where: whereClause }),
  ]);

  return Response.json({
    exercises,
    total: totalCount,
    page,
    limit,
    totalPages: Math.ceil(totalCount / limit),
  });
}

export async function POST(request: NextRequest) {
  try {
    const { userId }  = await auth();

    if (!userId) {
      return NextResponse.json(
        { error: "You must be signed in" },
        { status: 401 }
      );
    }

    // Check if user is admin
    const userInfo = await prisma.userInfo.findUnique({
      where: { userId },
      select: { role: true },
    });

    if (!userInfo || (userInfo.role !== "ADMIN" && userInfo.role !== "SUPER_ADMIN")) {
      return NextResponse.json(
        { error: "Admin access required" },
        { status: 403 }
      );
    }

    const body = await request.json();
    const {
      name,
      aliases = [],
      primary_muscles = [],
      secondary_muscles = [],
      primaryMuscles = [],
      secondaryMuscles = [],
      force,
      level,
      mechanic,
      equipment,
      category,
      instructions = [],
      description,
      tips = [],
      image,
    } = body;

    // Support both JSON format (primaryMuscles) and database format (primary_muscles)
    const finalPrimaryMuscles = primaryMuscles.length > 0 ? primaryMuscles : primary_muscles;
    const finalSecondaryMuscles = secondaryMuscles.length > 0 ? secondaryMuscles : secondary_muscles;

    // Validate required fields
    if (!name || !level || !category) {
      return NextResponse.json(
        { error: "Name, level, and category are required fields" },
        { status: 400 }
      );
    }

    // Generate directory name from exercise name
    const exerciseDirName = name.trim().replace(/[^a-zA-Z0-9_\-]/g, '_').replace(/_{2,}/g, '_');

    // Use provided image URL or default path
    const imagePath = image || `/images/exercises/${exerciseDirName}/images/0.jpg`;

    // Only create local files in development
    const isProduction = process.env.NODE_ENV === 'production';

    if (!isProduction) {
      const exerciseDir = join(process.cwd(), 'public', 'images', 'exercises', exerciseDirName);
      const imagesDir = join(exerciseDir, 'images');

      try {
        // Create the directory structure
        await mkdir(exerciseDir, { recursive: true });
        await mkdir(imagesDir, { recursive: true });

        // Create the exercise.json file
        const exerciseJson = {
          name: name.trim(),
          force: force || null,
          level,
          mechanic: mechanic || null,
          equipment: equipment || null,
          primaryMuscles: finalPrimaryMuscles,
          secondaryMuscles: finalSecondaryMuscles,
          instructions: instructions.filter((instruction: string) => instruction.trim()),
          category,
          ...(description?.trim() && { description: description.trim() }),
          ...(aliases.length > 0 && { aliases: aliases.filter((alias: string) => alias.trim()) }),
          ...(tips.length > 0 && { tips: tips.filter((tip: string) => tip.trim()) }),
        };

        const jsonPath = join(exerciseDir, 'exercise.json');
        await writeFile(jsonPath, JSON.stringify(exerciseJson, null, 2));

      } catch (fileError) {
        console.error("Error creating directories/files:", fileError);
        // Continue with database creation even if file operations fail
      }
    }

    // Create the exercise in database
    const newExercise = await prisma.exercise.create({
      data: {
        name: name.trim(),
        aliases: aliases.filter((alias: string) => alias.trim()),
        primary_muscles: finalPrimaryMuscles,
        secondary_muscles: finalSecondaryMuscles,
        force: force || null,
        level,
        mechanic: mechanic || null,
        equipment: equipment || null,
        category,
        instructions: instructions.filter((instruction: string) => instruction.trim()),
        description: description?.trim() || null,
        tips: tips.filter((tip: string) => tip.trim()),
        image: imagePath,
      },
    });

    return NextResponse.json({
      message: "Exercise created successfully",
      exercise: newExercise,
      directories: {
        exerciseDir: `/images/exercises/${exerciseDirName}`,
        imagesDir: `/images/exercises/${exerciseDirName}/images`,
        jsonFile: `/images/exercises/${exerciseDirName}/exercise.json`,
      },
    });
  } catch (error) {
    console.error("Error creating exercise:", error);
    return NextResponse.json(
      { error: "Failed to create exercise" },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    const { userId }  = await auth();

    if (!userId) {
      return NextResponse.json(
        { error: "You must be signed in" },
        { status: 401 }
      );
    }

    // Check if user is admin
    const userInfo = await prisma.userInfo.findUnique({
      where: { userId },
      select: { role: true },
    });

    if (!userInfo || (userInfo.role !== "ADMIN" && userInfo.role !== "SUPER_ADMIN")) {
      return NextResponse.json(
        { error: "Admin access required" },
        { status: 403 }
      );
    }

    const { searchParams } = new URL(request.url);
    const exerciseId = searchParams.get("id");

    if (!exerciseId) {
      return NextResponse.json(
        { error: "Exercise ID is required" },
        { status: 400 }
      );
    }

    const body = await request.json();
    const {
      name,
      aliases = [],
      primary_muscles = [],
      secondary_muscles = [],
      primaryMuscles = [],
      secondaryMuscles = [],
      force,
      level,
      mechanic,
      equipment,
      category,
      instructions = [],
      description,
      tips = [],
      image,
    } = body;

    // Support both JSON format (primaryMuscles) and database format (primary_muscles)
    const finalPrimaryMuscles = primaryMuscles.length > 0 ? primaryMuscles : primary_muscles;
    const finalSecondaryMuscles = secondaryMuscles.length > 0 ? secondaryMuscles : secondary_muscles;

    // Validate required fields
    if (!name || !level || !category) {
      return NextResponse.json(
        { error: "Name, level, and category are required fields" },
        { status: 400 }
      );
    }

    // Check if exercise exists
    const existingExercise = await prisma.exercise.findUnique({
      where: { id: exerciseId },
      select: { name: true, image: true },
    });

    if (!existingExercise) {
      return NextResponse.json(
        { error: "Exercise not found" },
        { status: 404 }
      );
    }

    // Generate directory name from exercise name (for new images)
    const exerciseDirName = name.trim().replace(/[^a-zA-Z0-9_\-]/g, '_').replace(/_{2,}/g, '_');

    // Use provided image URL, existing image, or generate default path
    const imagePath = image || existingExercise.image || `/images/exercises/${exerciseDirName}/images/0.jpg`;

    // Only update local files in development if name changed
    const isProduction = process.env.NODE_ENV === 'production';

    if (!isProduction && existingExercise.name !== name.trim()) {
      const exerciseDir = join(process.cwd(), 'public', 'images', 'exercises', exerciseDirName);
      const imagesDir = join(exerciseDir, 'images');

      try {
        // Create the directory structure for new name
        await mkdir(exerciseDir, { recursive: true });
        await mkdir(imagesDir, { recursive: true });

        // Create/update the exercise.json file
        const exerciseJson = {
          name: name.trim(),
          force: force || null,
          level,
          mechanic: mechanic || null,
          equipment: equipment || null,
          primaryMuscles: finalPrimaryMuscles,
          secondaryMuscles: finalSecondaryMuscles,
          instructions: instructions.filter((instruction: string) => instruction.trim()),
          category,
          ...(description?.trim() && { description: description.trim() }),
          ...(aliases.length > 0 && { aliases: aliases.filter((alias: string) => alias.trim()) }),
          ...(tips.length > 0 && { tips: tips.filter((tip: string) => tip.trim()) }),
        };

        const jsonPath = join(exerciseDir, 'exercise.json');
        await writeFile(jsonPath, JSON.stringify(exerciseJson, null, 2));

        // Try to remove old directory if name changed
        if (existingExercise.name !== name.trim()) {
          const oldExerciseDirName = existingExercise.name.trim().replace(/[^a-zA-Z0-9_\-]/g, '_').replace(/_{2,}/g, '_');
          const oldExerciseDir = join(process.cwd(), 'public', 'images', 'exercises', oldExerciseDirName);
          try {
            await rm(oldExerciseDir, { recursive: true, force: true });
          } catch (error) {
            console.warn("Could not delete old exercise directory:", error);
          }
        }

      } catch (fileError) {
        console.error("Error updating directories/files:", fileError);
        // Continue with database update even if file operations fail
      }
    }

    // Update the exercise in database
    const updatedExercise = await prisma.exercise.update({
      where: { id: exerciseId },
      data: {
        name: name.trim(),
        aliases: aliases.filter((alias: string) => alias.trim()),
        primary_muscles: finalPrimaryMuscles,
        secondary_muscles: finalSecondaryMuscles,
        force: force || null,
        level,
        mechanic: mechanic || null,
        equipment: equipment || null,
        category,
        instructions: instructions.filter((instruction: string) => instruction.trim()),
        description: description?.trim() || null,
        tips: tips.filter((tip: string) => tip.trim()),
        image: imagePath,
        date_updated: new Date(),
      },
    });

    return NextResponse.json({
      message: "Exercise updated successfully",
      exercise: updatedExercise,
    });
  } catch (error) {
    console.error("Error updating exercise:", error);
    return NextResponse.json(
      { error: "Failed to update exercise" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { userId }  = await auth();

    if (!userId) {
      return NextResponse.json(
        { error: "You must be signed in" },
        { status: 401 }
      );
    }

    // Check if user is admin
    const userInfo = await prisma.userInfo.findUnique({
      where: { userId },
      select: { role: true },
    });

    if (!userInfo || (userInfo.role !== "ADMIN" && userInfo.role !== "SUPER_ADMIN")) {
      return NextResponse.json(
        { error: "Admin access required" },
        { status: 403 }
      );
    }

    const { searchParams } = new URL(request.url);
    const exerciseId = searchParams.get("id");

    if (!exerciseId) {
      return NextResponse.json(
        { error: "Exercise ID is required" },
        { status: 400 }
      );
    }

    // Get exercise details before deletion
    const exercise = await prisma.exercise.findUnique({
      where: { id: exerciseId },
      select: { name: true },
    });

    if (!exercise) {
      return NextResponse.json(
        { error: "Exercise not found" },
        { status: 404 }
      );
    }

    // Delete from database first
    await prisma.exercise.delete({
      where: { id: exerciseId },
    });

    // Try to delete the directory structure
    const exerciseDirName = exercise.name.trim().replace(/[^a-zA-Z0-9_\-]/g, '_').replace(/_{2,}/g, '_');
    const exerciseDir = join(process.cwd(), 'public', 'images', 'exercises', exerciseDirName);

    try {
      await rm(exerciseDir, { recursive: true, force: true });
    } catch (fileError) {
      console.warn("Could not delete exercise directory:", fileError);
      // Continue even if file deletion fails
    }

    return NextResponse.json({
      message: "Exercise deleted successfully",
      exerciseName: exercise.name,
    });

  } catch (error) {
    console.error("Error deleting exercise:", error);
    return NextResponse.json(
      { error: "Failed to delete exercise" },
      { status: 500 }
    );
  }
}
