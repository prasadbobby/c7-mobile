import { auth } from "@clerk/nextjs/server";
import prisma from "@/prisma/prisma";
import PageHeading from "@/components/PageHeading/PageHeading";
import ExerciseFetch from "./_components/ExerciseFetch";
import ExerciseDetailModal from "./_components/Modals/ExerciseDetailModal/ExerciseDetailModal";
import ExerciseAddToRoutineModal from "./_components/Modals/ExerciseAddToRoutineModal";
import ExerciseFilters from "./_components/Filters/ExerciseFilters";
import { ExerciseAddToRoutineModalProvider } from "@/contexts/ExerciseAddToRoutineModalContext";
import AdminExerciseControls from "./_components/AdminExerciseControls";

export const dynamic = 'force-dynamic';

interface UserRoutine {
  name: string;
  id: string;
}

export default async function ExercisesPage({
  searchParams,
}: {
  searchParams?: {
    page?: number;
    perPage?: number;
    search?: string;
    muscle?: string;
    cat?: string;
    level?: string;
    force?: string;
    favs?: string;
    equipmentOwned?: string;
  };
}) {
  const { userId }: { userId: string | null }  = await auth();

  if (!userId) {
    throw new Error("You must be signed in to view this page.");
  }

  const perPage = Number(searchParams?.perPage) || 10;
  const search = searchParams?.search || "";
  const cat = searchParams?.cat ? searchParams?.cat.split(",") : [];
  const muscle = searchParams?.muscle ? searchParams?.muscle.split(",") : [];
  const level = searchParams?.level ? searchParams?.level.split(",") : [];
  const force = searchParams?.force ? searchParams?.force.split(",") : [];
  const currentPage = Number(searchParams?.page) || 1;
  const favs = searchParams?.favs === "true";
  const equipmentOwned = searchParams?.equipmentOwned === "true";

  // Check if user is admin
  const userInfo = await prisma.userInfo.findUnique({
    where: { userId },
    select: { role: true },
  });

  const isAdmin = userInfo?.role === "ADMIN" || userInfo?.role === "SUPER_ADMIN";

  const userRoutines: (UserRoutine & { exerciseCount: number })[] =
    await prisma.workoutPlan
      .findMany({
        where: {
          userId: userId,
        },
        select: {
          name: true,
          id: true,
          WorkoutPlanExercise: true,
        },
        orderBy: {
          createdAt: "desc",
        },
      })
      .then((routines) =>
        routines.map((routine) => ({
          ...routine,
          exerciseCount: routine.WorkoutPlanExercise.length,
        })),
      );

  return (
    <ExerciseAddToRoutineModalProvider>
      <PageHeading title="Exercises" />
      {isAdmin && <AdminExerciseControls />}
      <ExerciseFilters searchParams={searchParams} />
      {/* <Suspense 
        key={search + cat + muscle + level + force + currentPage} 
        fallback={<ExerciseTableSkeleton />}
      > */}
      <ExerciseFetch
        search={search}
        cat={cat}
        muscle={muscle}
        level={level}
        force={force}
        currentPage={currentPage}
        userRoutines={userRoutines}
        favs={favs}
        equipmentOwned={equipmentOwned}
        mode="exercisePage"
        perPage={perPage}
      />
      {/* </Suspense> */}
      <ExerciseDetailModal />
      <ExerciseAddToRoutineModal />
    </ExerciseAddToRoutineModalProvider>
  );
}
