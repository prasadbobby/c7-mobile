import { isClerkAPIResponseError, useClerk, useSignIn, useSSO } from '@clerk/clerk-expo';
import * as Linking from 'expo-linking';
import { router } from 'expo-router';
import * as WebBrowser from 'expo-web-browser';
import { ArrowLeft } from 'lucide-react-native';
import { useEffect, useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Reveal, useStagger } from './motion';
import { colors, font } from './theme';
import { IconButton, Txt } from './ui';

WebBrowser.maybeCompleteAuthSession();

export function AuthShell({ title, sub, children, footer }: { title: string; sub: string; children: React.ReactNode; footer: React.ReactNode }) {
  const insets = useSafeAreaInsets();
  const r = useStagger(3, { stagger: 0.1 });
  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: colors.surface }}>
      <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingTop: insets.top + 16, paddingBottom: insets.bottom + 24, paddingHorizontal: 24, flexGrow: 1 }}>
        <IconButton icon={ArrowLeft} label="Go back" tint={colors.card} onPress={() => (router.canGoBack() ? router.back() : router.replace('/login'))} />
        <Reveal p={r[0]!}>
          <Txt v="h1" style={{ textAlign: 'center', marginTop: 48, fontFamily: font.semibold }}>
            {title}
          </Txt>
          <Txt color={colors.textMuted} style={{ textAlign: 'center', marginTop: 12, marginBottom: 32 }}>
            {sub}
          </Txt>
        </Reveal>
        <Reveal p={r[1]!} style={{ gap: 14 }}>
          {children}
        </Reveal>
        <View style={{ flex: 1 }} />
        <Reveal p={r[2]!}>{footer}</Reveal>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

export const INVITE_ONLY = 'C7 is invite-only. Ask your coach or the front desk to invite this email, then accept the invite and sign in here.';

/** Human message for Clerk errors (no raw codes on screen). */
export function authError(e: unknown): string {
  if (isClerkAPIResponseError(e)) {
    const err = e.errors[0];
    switch (err?.code) {
      case 'form_identifier_not_found':
      case 'not_allowed_access':
      case 'sign_up_restricted_waitlist':
      case 'external_account_not_found':
        return INVITE_ONLY;
      case 'form_code_incorrect':
        return 'That code isn’t right. Check the latest email and try again.';
      case 'verification_expired':
        return 'That code expired. Tap “Resend code” for a new one.';
      case 'too_many_requests':
        return 'Too many attempts. Wait a minute and try again.';
      default:
        return err?.longMessage || err?.message || 'Sign-in failed. Please try again.';
    }
  }
  return e instanceof Error ? e.message : 'Sign-in failed. Please try again.';
}

/** Email one-time-code sign-in (Clerk email_code). */
export function useEmailCode() {
  const { signIn, setActive, isLoaded } = useSignIn();
  return {
    isLoaded,
    async send(email: string) {
      if (!signIn) throw new Error('Still loading, try again');
      const si = await signIn.create({ identifier: email.trim().toLowerCase() });
      const factor = si.supportedFirstFactors?.find((f) => f.strategy === 'email_code') as { emailAddressId: string } | undefined;
      if (!factor) throw new Error('Email codes aren’t enabled for this account. Use Google instead.');
      await signIn.prepareFirstFactor({ strategy: 'email_code', emailAddressId: factor.emailAddressId });
      return factor.emailAddressId;
    },
    async resend(emailAddressId: string) {
      await signIn!.prepareFirstFactor({ strategy: 'email_code', emailAddressId });
    },
    async verify(code: string) {
      const r = await signIn!.attemptFirstFactor({ strategy: 'email_code', code });
      if (r.status !== 'complete' || !r.createdSessionId) throw new Error('Additional verification is required. Sign in on the web once, then try again.');
      await setActive!({ session: r.createdSessionId });
    },
  };
}

/** Google sign-in. Native: in-app browser SSO. Web: full-page redirect back to /sso-callback. */
export function useGoogle() {
  const { startSSOFlow } = useSSO();
  const { signIn } = useSignIn();
  return async () => {
    if (Platform.OS === 'web') {
      await signIn!.authenticateWithRedirect({ strategy: 'oauth_google', redirectUrl: `${window.location.origin}/sso-callback`, redirectUrlComplete: `${window.location.origin}/` });
      return false;
    }
    const { createdSessionId, setActive, signUp } = await startSSOFlow({ strategy: 'oauth_google', redirectUrl: Linking.createURL('sso-callback') });
    if (createdSessionId) {
      await setActive!({ session: createdSessionId });
      return true;
    }
    // A Google account with no invited C7 account lands in an incomplete sign-up.
    if (signUp && signUp.status !== 'complete') throw new Error(INVITE_ONLY);
    return false;
  };
}

/** Web only: finishes the Google redirect. */
export function SsoCallbackHandler() {
  const clerk = useClerk();
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    clerk
      .handleRedirectCallback({ signInFallbackRedirectUrl: '/', signUpFallbackRedirectUrl: '/' }, async (to) => router.replace(to.startsWith('/') ? (to as '/') : '/'))
      .catch((e) => setError(authError(e)));
  }, [clerk]);
  return (
    <View style={{ flex: 1, backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 12 }}>
      <Txt v="h3">{error ? 'Couldn’t sign you in' : 'Signing you in…'}</Txt>
      {!!error && (
        <Txt color={colors.textMuted} style={{ textAlign: 'center' }} onPress={() => router.replace('/login')}>
          {error} Tap to go back.
        </Txt>
      )}
    </View>
  );
}
