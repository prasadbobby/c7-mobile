/// <reference types="node" />
import { execSync } from 'node:child_process';
import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
const BACKEND = process.env.BACKEND_DIR ?? '../c7-backend';

/** Mobile-only scenario: Regina has one workout due today and one due tomorrow (date-wise Home / Workout tab). */
const MOBILE_SCENARIO = `
import pg from 'pg';
import { TEST_DB, USERS } from '__FIXTURES__';
const c = new pg.Client({ connectionString: TEST_DB });
await c.connect();
const plan = async (n) => (await c.query('SELECT id FROM "WorkoutPlan" WHERE name=$1', [n])).rows[0].id;
const noon = (d) => { const x = new Date(); x.setUTCHours(12, 0, 0, 0); x.setUTCDate(x.getUTCDate() + d); return x; };
const ins = 'INSERT INTO "AssignedWorkout"(id,"userId","workoutPlanId","assignedBy",status,notes,"dueDate") VALUES ($1,$2,$3,$4,$5,$6,$7)';
await c.query(ins, ['assign_b_today', USERS.buddy.userId, await plan('Lower Body Strength'), USERS.admin.userId, 'PENDING', 'Heavy day', noon(0)]);
await c.query(ins, ['assign_b_tomorrow', USERS.buddy.userId, await plan('Full Body Foundations'), USERS.admin.userId, 'PENDING', 'Light day', noon(1)]);
await c.end();
`;

/** Fresh c7test DB with seed + scenario data (reuses the backend's API-test setup), plus the mobile scenario. */
export default async function () {
  execSync(`npx tsx -e "import('./tests/global-setup.ts').then(m => m.default())"`, { cwd: BACKEND, stdio: 'inherit' });
  const file = join(mkdtempSync(join(tmpdir(), 'c7-e2e-')), 'scenario.mts');
  writeFileSync(file, MOBILE_SCENARIO.replace('__FIXTURES__', resolve(BACKEND, 'tests/fixtures.ts')).replace("from 'pg'", `from '${resolve(BACKEND, 'node_modules/pg/lib/index.js')}'`));
  execSync(`npx tsx ${file}`, { cwd: BACKEND, stdio: 'inherit' });
}
