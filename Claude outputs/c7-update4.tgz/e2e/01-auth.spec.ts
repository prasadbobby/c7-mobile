import { completeSetup, expect, signedOut, test } from './fixtures';

test('first launch shows onboarding, then the invite-only login', async ({ page }) => {
  await signedOut(page, false);
  await page.goto('/');
  await expect(page).toHaveURL(/onboarding/);
  await page.getByText(/skip/i).first().click().catch(() => {});
  await page.goto('/login');
  await expect(page.getByText('Let’s log you in')).toBeVisible();
  await expect(page.getByText('C7 is invite-only.')).toBeVisible();
  await page.getByText('How do I get access?').click();
  await expect(page.getByText('Invite-only access')).toBeVisible();
  await expect(page.getByText('Your coach invites you')).toBeVisible();
});

test('an email that was not invited is refused with a clear message', async ({ page }) => {
  await signedOut(page);
  await page.goto('/email-login');
  await page.getByLabel('Email').fill('stranger@example.com');
  await page.getByText('Send code').click();
  await expect(page.getByText(/C7 is invite-only. Ask your coach/)).toBeVisible();
});

test('wrong code is rejected, right code signs in; invited member completes first-time setup', async ({ page, errors }) => {
  await signedOut(page);
  await page.goto('/email-login');
  await page.getByLabel('Email').fill('invited@c7.test');
  await page.getByText('Send code').click();
  await expect(page.getByText(/A 6-digit code has been sent to invited@c7.test/)).toBeVisible();
  await page.getByLabel('Verification code').fill('111111');
  await expect(page.getByText(/That code isn’t right/)).toBeVisible();
  await page.getByLabel('Verification code').fill('424242');
  // First sign-in of an invited member creates their C7 profile and starts setup.
  await expect(page.getByLabel('First name')).toHaveValue('Nina'); // prefilled from the invite
  await completeSetup(page);
  await expect(page.getByText('Hello Nina 👋')).toBeVisible();
  expect(errors).toEqual([]);
});

test('a locked account sees the locked screen and can sign out', async ({ page, signIn }) => {
  await signIn('locked');
  await expect(page.getByText('Account locked')).toBeVisible();
  await page.getByText('SIGN OUT').click();
  await expect(page.getByText('Let’s log you in')).toBeVisible();
});
