import { expect, test } from './fixtures';

const routes = ['/home', '/workout', '/stats', '/meals', '/profile', '/challenges', '/leaderboard', '/notifications', '/achievements', '/streak', '/history', '/body', '/saved', '/search', '/settings', '/membership', '/goals'];

for (const r of routes)
  test(`screen ${r} renders real data without errors`, async ({ page, signIn, errors }) => {
    await signIn('buddy');
    await page.goto(r);
    await page.waitForLoadState('networkidle');
    await expect(page.getByText('Couldn’t load this')).toHaveCount(0);
    await expect(page.locator('body')).not.toBeEmpty();
    expect(errors).toEqual([]);
  });
