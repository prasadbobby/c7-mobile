#!/usr/bin/env node
/**
 * Guards against React Native "Unexpected text node … cannot be a child of a <View>" errors.
 *  1. Raw JSX text outside <Txt>/<Text>.
 *  2. `{x && <El/>}` inside a non-text element where `x` isn't clearly boolean —
 *     when x is '' or 0 React renders that value as a text node. Use `!!x &&` or a ternary.
 * Run: npm run check:jsx   (add --fix to rewrite `x &&` → `!!x &&`)
 */
const fs = require('fs');
const path = require('path');
const { parse } = require('@babel/parser');
const traverse = require('@babel/traverse').default;

const ROOTS = ['app', 'src'];
const TEXT_TAGS = /^(Txt|Text|Animated\.Text|SvgText|TSpan|TextPath)$/;
const fix = process.argv.includes('--fix');

const files = [];
const walk = (d) => fs.existsSync(d) && fs.readdirSync(d).forEach((f) => { const p = path.join(d, f); fs.statSync(p).isDirectory() ? walk(p) : /\.tsx$/.test(p) && files.push(p); });
ROOTS.forEach(walk);

const tagName = (n) => (n.type === 'JSXIdentifier' ? n.name : n.type === 'JSXMemberExpression' ? `${tagName(n.object)}.${n.property.name}` : '?');
const isBooleanish = (e) =>
  (e.type === 'UnaryExpression' && e.operator === '!') ||
  e.type === 'BooleanLiteral' ||
  (e.type === 'BinaryExpression' && ['===', '!==', '==', '!=', '<', '>', '<=', '>=', 'in', 'instanceof'].includes(e.operator)) ||
  (e.type === 'LogicalExpression' && isBooleanish(e.left) && isBooleanish(e.right)) ||
  (e.type === 'CallExpression' && e.callee.type === 'Identifier' && e.callee.name === 'Boolean') ||
  (e.type === 'CallExpression' && e.callee.type === 'MemberExpression' && ['includes', 'some', 'every', 'has', 'startsWith', 'endsWith', 'test', 'isArray'].includes(e.callee.property.name)) ||
  (e.type === 'Identifier' && /^(is|has|can|should|show|open|visible|active|focused|loading|busy|done|ready|selected|editing|enabled|disabled|compact|signedIn|isToday)/.test(e.name)) ||
  (e.type === 'MemberExpression' && !e.computed && /^(is|has|can|show|open|visible|active|isLoading|isError|isFetching|isPending|isFetchingNextPage|hasNextPage|enabled|liked|saved|done|completed|ready)/.test(e.property.name));

let problems = 0;
for (const file of files) {
  const src = fs.readFileSync(file, 'utf8');
  const ast = parse(src, { sourceType: 'module', plugins: ['typescript', 'jsx'] });
  const edits = [];
  traverse(ast, {
    JSXText(p) {
      const parent = p.parentPath.node;
      if (!p.node.value.trim() || parent.type !== 'JSXElement') return;
      if (TEXT_TAGS.test(tagName(parent.openingElement.name))) return;
      problems++; console.log(`${file}:${p.node.loc.start.line}  raw text ${JSON.stringify(p.node.value.trim())} inside <${tagName(parent.openingElement.name)}>`);
    },
    JSXExpressionContainer(p) {
      const parent = p.parentPath.node;
      if (parent.type !== 'JSXElement' || TEXT_TAGS.test(tagName(parent.openingElement.name))) return;
      const e = p.node.expression;
      if (e.type !== 'LogicalExpression' || e.operator !== '&&' || isBooleanish(e.left)) return;
      // Objects/arrays from queries are fine; only flag when the left side could be a string/number.
      problems++; edits.push(e.left);
      console.log(`${file}:${e.loc.start.line}  \`${src.slice(e.left.start, e.left.end)} && …\` inside <${tagName(parent.openingElement.name)}> — use !!(…) or a ternary`);
    },
  });
  if (fix && edits.length) {
    let out = src;
    for (const l of edits.sort((a, b) => b.start - a.start)) {
      const t = src.slice(l.start, l.end);
      const simple = ['Identifier', 'MemberExpression', 'OptionalMemberExpression'].includes(l.type);
      out = out.slice(0, l.start) + (simple ? `!!${t}` : `!!(${t})`) + out.slice(l.end);
    }
    fs.writeFileSync(file, out);
  }
}
if (problems && !fix) { console.error(`\n✖ ${problems} JSX text-node risk(s). Run: npm run check:jsx -- --fix`); process.exit(1); }
console.log(fix ? `Fixed ${problems} expression(s).` : '✓ No JSX text-node risks.');
